from django.contrib.auth.forms import UserCreationForm 
from django import forms
from django.forms import ModelForm
from django.db import transaction
from .models import User,Salesexecutive , Abm , Zbm , Rbm , Profile

class SESignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    phone_number = forms.CharField(required=True)
    location = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User
    
    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_se = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.save()
        se = Salesexecutive.objects.create(user=user)
        se.phone_number=self.cleaned_data.get('phone_number')
        se.location=self.cleaned_data.get('location')
        se.save()
        return user

class ABMSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    phone_number = forms.CharField(required=True)
    area = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_abm = True
        user.is_staff = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.save()
        abm = Abm.objects.create(user=user)
        abm.phone_number=self.cleaned_data.get('phone_number')
        abm.area=self.cleaned_data.get('designation')
        abm.save()
        return user

class ZBMSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    phone_number = forms.CharField(required=True)
    zone = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_zbm = True
        user.is_staff = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.save()
        zbm = Zbm.objects.create(user=user)
        zbm.phone_number=self.cleaned_data.get('phone_number')
        zbm.zone=self.cleaned_data.get('designation')
        zbm.save()
        return user


class RBMSignUpForm(UserCreationForm):
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    phone_number = forms.CharField(required=True)
    region = forms.CharField(required=True)

    class Meta(UserCreationForm.Meta):
        model = User

    @transaction.atomic
    def save(self):
        user = super().save(commit=False)
        user.is_rbm = True
        user.is_staff = True
        user.first_name = self.cleaned_data.get('first_name')
        user.last_name = self.cleaned_data.get('last_name')
        user.save()
        rbm = Rbm.objects.create(user=user)
        rbm.phone_number=self.cleaned_data.get('phone_number')
        rbm.area=self.cleaned_data.get('designation')
        rbm.save()
        return user


def ProfileForm(ModelForm):

    class Meta :
        model = Profile 
        field = ['image' , ' info' ]
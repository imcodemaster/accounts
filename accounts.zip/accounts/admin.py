from django.contrib import admin
from .models import User, Salesexecutive, Abm, Rbm, Zbm , Admin , Profile

admin.site.register(User)
admin.site.register(Salesexecutive)
admin.site.register(Abm)
admin.site.register(Rbm)
admin.site.register(Zbm)
admin.site.register(Admin)

admin.site.register(Profile)

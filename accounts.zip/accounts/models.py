
from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
	is_se = models.BooleanField(default = False)
	is_abm = models.BooleanField(default = False)
	is_rbm = models.BooleanField(default = False)
	is_zbm = models.BooleanField(default = False)
	is_admin = models.BooleanField(default = False)
	first_name = models.CharField(max_length = 15)
	last_name = models.CharField(max_length = 15)


class Salesexecutive(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	mobile_number = models.CharField(max_length = 15) 
	email = models.EmailField()
	location = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'

class Abm(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	mobile_number = models.CharField(max_length = 15) 
	email = models.EmailField()
	area = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'

class Rbm(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	mobile_number = models.CharField(max_length = 15) 
	email = models.EmailField()
	region = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'

class Zbm(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	mobile_number = models.CharField(max_length = 15) 
	email = models.EmailField()
	Zone = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'


class Admin(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	mobile_number = models.CharField(max_length = 15) 
	email = models.EmailField()
	company = models.CharField(max_length = 15 , null = True , blank = True)

	def __str__(self):
		return f'{self.user.username}'



# User_profile creation models 


class Profile(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , primary_key = True)
	image = models.ImageField(default = 'default.jpg' , upload_to = 'profiles_pics')
	info  = models.CharField(max_length = 100 , null = True , blank = True)



	def __str__(self):
		return f'{self.user.username} Profile'

	






